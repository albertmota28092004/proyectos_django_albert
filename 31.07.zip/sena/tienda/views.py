from django.http import HttpResponse
from django.shortcuts import render
from .models import Categoria, Producto

# Create your views here.

def index(request):
    return render(request, "tienda/index.html")

def login(request):
    return render(request, "tienda/login.html")

def categorias(request):
    return render(request, "tienda/categorias/listar.html")

def alimento(request):
    resultado = Categoria.objects.all()
    context = {"data": resultado}
    # select * from Categoria
    return render(request, "tienda/categorias_inicio/productos/alimento.html")

def delimpieza(request):
    return render(request, "tienda/categorias_inicio/productos/delimpieza.html")

def vacunas(request):
    return render(request, "tienda/categorias_inicio/productos/vacunas.html")

def estetica(request):
    return render(request, "tienda/categorias_inicio/servicios/estetica.html")

def salud(request):
    return render(request, "tienda/categorias_inicio/servicios/salud.html")

def vacunacion(request):
    return render(request, "tienda/categorias_inicio/servicios/vacunacion.html")

def historia(request):
    return render(request, "tienda/categorias_inicio/quienesSomos/historia.html")

def nuestroequipo(request):
    return render(request, "tienda/categorias_inicio/quienesSomos/nuestroequipo.html")

def patrocinios(request):
    return render(request, "tienda/categorias_inicio/quienesSomos/patrocinios.html")

def contactanos(request):
    return render(request, "tienda/categorias_inicio/contactanos/contactanos.html")